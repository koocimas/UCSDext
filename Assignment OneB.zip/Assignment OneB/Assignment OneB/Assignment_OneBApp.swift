//
//  Assignment_OneBApp.swift
//  Assignment OneB
//
//  Created by Sam Cook on 1/12/24.
//

import SwiftUI

@main
struct Assignment_OneBApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

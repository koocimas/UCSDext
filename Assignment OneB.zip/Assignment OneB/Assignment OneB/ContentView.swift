//
//  ContentView.swift
//  Assignment OneB
//
//  Created by Sam Cook on 1/12/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Where do we come from")
                .font(/*@START_MENU_TOKEN@*/.body/*@END_MENU_TOKEN@*/)
                .fontWeight(.light)
                .italic()
            Text("Where do we go")
                .font(.body)
                .fontWeight(.thin)
            Text("Where do we come from")
                .font(.footnote)
                .fontWeight(.ultraLight)
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            Button("Reveal") {
            }
            .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.83, saturation: 0.266, brightness: 0.958)/*@END_MENU_TOKEN@*/)
            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            .accentColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
            .buttonBorderShape(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=shape: ButtonBorderShape@*/.roundedRectangle/*@END_MENU_TOKEN@*/)
            .padding()
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

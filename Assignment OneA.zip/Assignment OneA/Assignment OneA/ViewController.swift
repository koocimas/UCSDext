//
//  ViewController.swift
//  Assignment OneA
//
//  Created by Sam Cook on 1/12/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


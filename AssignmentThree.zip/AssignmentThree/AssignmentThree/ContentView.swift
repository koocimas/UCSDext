//
//  ContentView.swift
//  AssignmentThree
//
//  Created by Sam Cook on 1/27/24.
//

import SwiftUI

struct ContentView: View {
    @State private var myText = "James Bond"
    var body: some View {
        VStack(spacing: 2.0) {
            Text("My super secret agent name is:")
                .fontWeight(.bold)
                .font(.callout)
            Text(myText)
                .font(/*@START_MENU_TOKEN@*/.largeTitle/*@END_MENU_TOKEN@*/)
            Spacer()
                .font(/*@START_MENU_TOKEN@*/.largeTitle/*@END_MENU_TOKEN@*/)
            TextField("Enter your secret agent name here...", text: $myText)
                .keyboardType(/*@START_MENU_TOKEN@*/.alphabet/*@END_MENU_TOKEN@*/)
                .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
            }
                .padding()
        }
    }
    
    #Preview {
        ContentView()
    }

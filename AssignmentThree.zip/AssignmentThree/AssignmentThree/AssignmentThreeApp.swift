//
//  AssignmentThreeApp.swift
//  AssignmentThree
//
//  Created by Sam Cook on 1/27/24.
//

import SwiftUI

@main
struct AssignmentThreeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

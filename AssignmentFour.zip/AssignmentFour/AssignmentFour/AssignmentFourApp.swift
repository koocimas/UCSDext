//
//  AssignmentFourApp.swift
//  AssignmentFour
//
//  Created by Sam Cook on 2/1/24.
//

import SwiftUI

@main
struct AssignmentFourApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  ContentView.swift
//  AssignmentFour
//
//  Created by Sam Cook on 2/1/24.
//

import SwiftUI

struct ContentView: View {
    @State private var fullText: String = "Entree"
    @State private var selectedCarb: Carbs = .noodles
    @State private var onOrOff: Bool = true
    
    let favoriteEntrees = ["BBQ Ribs", "Teriyaki Salmon", "Fried Chicken", "Filet Mignon"]
    
    func chooseEntree() {
        let randomEntree = favoriteEntrees.randomElement()!
        fullText = "\(randomEntree)"
    }
    
    enum Carbs: String {
        case noodles = "Noodles"
        case rice = "Rice"
        case potatoes = "Potatoes"
    }
    
    var body: some View {
        VStack {
            Text("🍳🍳🍳 \n Cook Something Yummy".uppercased())
                .multilineTextAlignment(.center)
                .font(.largeTitle)
                .bold()
            
            HStack {
                Text(fullText)
                    .padding()
                    .background(Color.pink)
                Text("Served with: \(selectedCarb.rawValue)")
                    .padding()
                    .background(Color.purple)
                Text(onOrOff ? "OVEN ON" : " OVEN OFF")
                    .padding()
                    .background(onOrOff ? Color.green : Color.yellow)
            }
            Spacer()
            
            Button(action: chooseEntree) {
                Text("Click for Mystery Entree")
                    .font(.largeTitle)
                    .padding(0.25)
                    .background(Color.blue)
                    .foregroundColor(.white)
            }
            
            Picker("Pet picker", selection: $selectedCarb) {
                Text(Carbs.noodles.rawValue).tag(Carbs.noodles)
                Text(Carbs.rice.rawValue).tag(Carbs.rice)
                Text(Carbs.potatoes.rawValue).tag(Carbs.potatoes)
            }
            .pickerStyle(.segmented)
                        
            Toggle(isOn: $onOrOff) {
                Text("Oven Cook")
            }
        }
    }
}

#Preview {
    ContentView()
}

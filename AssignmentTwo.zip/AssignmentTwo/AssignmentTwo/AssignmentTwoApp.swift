//
//  AssignmentTwoApp.swift
//  AssignmentTwo
//
//  Created by Sam Cook on 1/19/24.
//

import SwiftUI

@main
struct AssignmentTwoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

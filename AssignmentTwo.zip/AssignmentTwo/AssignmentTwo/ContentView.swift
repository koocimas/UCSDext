//
//  ContentView.swift
//  AssignmentTwo
//
//  Created by Sam Cook on 1/19/24.
//

import SwiftUI

struct ContentView: View {
    @State var backgroundColor = Color.red
    var body: some View {
        VStack {
            ZStack {
                Rectangle()
                    .frame(width: 250.0, height: 150.0)
                    .foregroundColor(backgroundColor)
                Text("I warned you!")
                }
                .foregroundColor(Color.red)
                HStack {
                    Button("Don't you dare tap this button") {
                        backgroundColor = Color.clear
                    }
                }
            }
        }
    
    }

#Preview {
    ContentView()
}
